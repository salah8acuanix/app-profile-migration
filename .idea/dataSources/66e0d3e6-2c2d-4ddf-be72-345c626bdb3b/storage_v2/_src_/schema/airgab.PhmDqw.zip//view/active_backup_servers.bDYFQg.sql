create view active_backup_servers as
select count(1) AS `no_active_servers`
from `airgab`.`backup_servers`;

