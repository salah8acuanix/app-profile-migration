create view inactive_users as
select count(1) AS `no_of_inactive_usrs`
from `airgab`.`users`
where (`airgab`.`users`.`deleted` = 1);

