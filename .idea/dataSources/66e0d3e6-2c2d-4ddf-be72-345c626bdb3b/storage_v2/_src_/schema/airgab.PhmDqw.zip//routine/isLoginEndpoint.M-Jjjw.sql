create
    definer = airgab@`%` function isLoginEndpoint(server_id int) returns tinyint(1)
BEGIN
	IF (select SUM(is_login) from endpoints where node_id = server_id) > 0 THEN 
		RETURN true;
	ELSE 
		RETURN false;
	END IF;
END;

