create view lock_unlock_switch_info as
select `airgab`.`network_switch`.`id` AS `id`, `airgab`.`network_switch`.`port_opened_at` AS `port_opened_at`
from `airgab`.`network_switch`
where (`airgab`.`network_switch`.`current_active` = 1);

