create view notification_settings_view as
select `d`.`id`               AS `id`,
       `n`.`user_id`          AS `user_id`,
       `n`.`notify_email`     AS `notify_email`,
       `n`.`notify_phone`     AS `notify_phone`,
       `d`.`notify_via_email` AS `via_email_selected`,
       `d`.`notify_via_sms`   AS `via_phone_selected`,
       `d`.`severity`         AS `severity`
from (`airgab`.`notifications_settings` `n`
         join `airgab`.`notifications_settings_dtls` `d`)
where ((`n`.`id` = `d`.`parent_notification_id`) and (`d`.`has_access` in (0, 1)));

