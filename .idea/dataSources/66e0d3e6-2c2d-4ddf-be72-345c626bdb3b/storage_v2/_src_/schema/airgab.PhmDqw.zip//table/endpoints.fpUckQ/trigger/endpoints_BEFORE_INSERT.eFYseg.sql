create definer = airgab@`%` trigger endpoints_BEFORE_INSERT
    before insert
    on endpoints
    for each row
BEGIN
	 IF isLoginEndpoint(new.node_id) AND new.is_login =	 1 THEN
		 SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Single login endpoint is allowed per backup server/ network switch!!!', MYSQL_ERRNO = 1001;
     END IF;
END;

