create definer = airgab@`%` trigger endpoints_BEFORE_UPDATE
    before update
    on endpoints
    for each row
BEGIN
if OLD.is_login = 0 then
	IF isLoginEndpoint(new.node_id) AND new.is_login = 1 THEN
		 SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Single login endpoint is allowed per backup server/ network switch!!!', MYSQL_ERRNO = 1001;
     END IF;
else If OLD.is_login = 1 then
	IF updateLoginEndpoint(new.node_id) AND new.is_login = 1 THEN
		 SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Single login endpoint is allowed per backup server/ network switch!!!', MYSQL_ERRNO = 1001;
     END IF;
end if;

end if;
END;

