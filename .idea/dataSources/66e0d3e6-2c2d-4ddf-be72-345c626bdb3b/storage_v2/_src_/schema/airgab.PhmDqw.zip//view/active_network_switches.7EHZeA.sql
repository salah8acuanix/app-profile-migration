create view active_network_switches as
select count(0) AS `no_active_switches`
from `airgab`.`network_switch`;

