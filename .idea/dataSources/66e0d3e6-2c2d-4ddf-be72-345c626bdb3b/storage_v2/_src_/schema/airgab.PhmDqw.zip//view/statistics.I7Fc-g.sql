create view statistics as
select 1                                              AS `id`,
       `active_users`.`no_of_active_usrs`             AS `no_of_active_usrs`,
       `inactive_users`.`no_of_inactive_usrs`         AS `no_of_inactive_usrs`,
       `active_workflows`.`no_of_active_flows`        AS `no_of_active_flows`,
       `inactive_workflows`.`no_of_inactive_flows`    AS `no_of_inactive_flows`,
       `active_network_switches`.`no_active_switches` AS `no_active_switches`,
       `active_backup_servers`.`no_active_servers`    AS `no_active_servers`,
       `number_of_endpoints`.`endpoints_number`       AS `endpoints_number`
from ((((((`airgab`.`active_users` join `airgab`.`inactive_users`) join `airgab`.`active_workflows`) join `airgab`.`inactive_workflows`) join `airgab`.`active_backup_servers`) join `airgab`.`active_network_switches`)
         join `airgab`.`number_of_endpoints`);

