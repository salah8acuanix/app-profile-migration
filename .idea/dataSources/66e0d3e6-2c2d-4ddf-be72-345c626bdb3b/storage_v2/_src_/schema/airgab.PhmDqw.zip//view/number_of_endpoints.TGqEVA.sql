create view number_of_endpoints as
select count(0) AS `endpoints_number`
from `airgab`.`endpoints`;

