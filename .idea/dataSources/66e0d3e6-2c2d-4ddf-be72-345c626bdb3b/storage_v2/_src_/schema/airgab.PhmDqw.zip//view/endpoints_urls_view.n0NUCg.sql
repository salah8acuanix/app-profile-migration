create view endpoints_urls_view as
select `airgab`.`endpoints`.`id`        AS `id`,
       `airgab`.`endpoints`.`node_type` AS `node_type`,
       `airgab`.`endpoints`.`url`       AS `url`
from `airgab`.`endpoints`;

-- comment on column endpoints_urls_view.node_type not supported: 0 : for Backup server 
1 : for NW Sw

