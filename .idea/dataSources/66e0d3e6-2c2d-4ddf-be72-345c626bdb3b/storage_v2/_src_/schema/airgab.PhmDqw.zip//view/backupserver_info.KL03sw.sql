create view backupserver_info as
select `b`.`id`           AS `server_id`,
       `b`.`name`         AS `server_name`,
       `b`.`type`         AS `server_type`,
       `b`.`api_url`      AS `server_api_url`,
       `b`.`api_username` AS `server_api_username`,
       `b`.`api_password` AS `server_api_password`,
       `e`.`method`       AS `server_api_url_method`,
       `u`.`url`          AS `server_login_url`
from ((`airgab`.`backup_servers` `b` join `airgab`.`endpoints` `e`)
         join `airgab`.`backup_server_type_version_apis_url` `u`
              on (((`e`.`node_type` = 0) and (`e`.`is_login` = 1) and (`b`.`id` = `e`.`node_id`) and
                   (`u`.`id` = `e`.`url`))));

-- comment on column backupserver_info.server_api_url_method not supported: GET
POST
PUT
DELETE

