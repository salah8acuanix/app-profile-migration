create view active_workflows as
select count(1) AS `no_of_active_flows`
from `airgab`.`workflows`
where (`airgab`.`workflows`.`active` = 1);

