create view inactive_workflows as
select count(1) AS `no_of_inactive_flows`
from `airgab`.`workflows`
where (`airgab`.`workflows`.`active` = 0);

