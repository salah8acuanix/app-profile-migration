create view active_users as
select count(1) AS `no_of_active_usrs`
from `airgab`.`users`
where ((`airgab`.`users`.`deleted` = 0) and (`airgab`.`users`.`is_super_admin` = 0));

